<html>
	<body>
		<center>
		<?php
		
		//VARIABLES DE CONNEXION
		$dbhost="localhost"; 		
		$dbbase="atelier";
		$dbuser="root";
		$dbpassword="";

		//CONNEXION
		$dbh = mysql_connect($dbhost, $dbuser, $dbpassword) or die ('I cannot connect to the database because: ' . mysql_error());

		//SELECTION
		mysql_select_db ($dbbase) or die("S�lection de la base de donn�es impossible");

		//REQUETE
		$query = "select * from participants order by nom asc"
			or die (mysql_error()."<br />couldn't execute query: $query"); 

		//RESULTATS
		$result = mysql_query($query);
		
		while($row = mysql_fetch_array($result)){ // lignes affect�es par la requ�te
		
		// AFFICHAGE DES RESULTATS
		echo $row["nom"]."<br>";		
		}
		?>
		
		</center> 
	</body>
</html>
