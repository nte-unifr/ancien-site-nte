Kurzinformation zum AKAB CBT-Kriterienkatalog

Das Angebot an Computer Based Training (CBT) Programmen hat in den letzten 
Jahren einen stetigen Anstieg erfahren. Kaum ein gr��eres Unternehmen verzichtet 
heute noch auf den Einsatz von CBT-Programmen in der Aus- und Weiterbildung. 
Dabei stellt sich allerdings vielen Bildungsverantwortlichen die Frage, wie aus dieser 
Vielzahl von Angeboten ein "gutes" Lernprogramm herausgefiltert werden kann? 
Dies war auch f�r den Arbeitskreis Automobilindustrie Bildung (AKAB) der Grund, 
einen Kriterienkatalog zu entwickeln, anhand dessen die Qualit�t einzelner CBT-
Programme eingesch�tzt werden kann.

Unser Arbeitskreis setzt sich aus den Automobilherstellern Audi, BMW, Ford, 
Mercedes-Benz, Opel, Porsche und VW sowie dem Zulieferer Bosch zusammen. 
Innerhalb des AKAB wurde vor drei Jahren der Arbeitskreis Selbstlernen gegr�ndet. 
Ziel war es, eine Informationsplattform zu schaffen, sich �ber Produkte auszutau-
schen, Projektfinanzierungen f�r Lernprogramme zu finden und Qualit�tskriterien f�r 
eine Beurteilung von CBT-Programmen zu entwickeln. Die Entwicklung solcher 
Qualit�tskriterien war uns wichtig, um bei der Beurteilung von Lernprogrammen die 
"gleiche Sprache" zu sprechen und um auch den Herstellern einen klaren Hinweis 
geben zu k�nnen, was wir unter Qualit�t verstehen.

In den Kriterienkatalog ist vielf�ltiger Sachverstand eingeflossen: unsere Erfahrun-
gen aus der Praxis; wissenschaftliche Erkenntnisse aus mehreren Diplomarbeiten 
und einschl�giger Fachliteratur; und nicht zuletzt das Feedback von Anwendern, die 
ihre Vorstellungen von guten Lernprogrammen erl�uterten.

Wir sind uns dar�ber klar, da� dieser Kriterienkatalog kein valides Beurteilungs-
instrument darstellt, da wir unser Hauptaugenmerk vor allem auf die methodisch-
didaktische Beurteilung von Lernprogrammen gerichtet haben. Unserer Meinung 
nach kann es nicht  d i e  absolut g�ltigen Kriterien geben, denn ein einzelnes Lern-
programm kann nicht losgel�st von Einfl�ssen, die beim Lernenden selbst, der 
jeweiligen Lernsituation und der Lernkultur in einem Unternehmen liegen, betrachtet 
werden. 

Unsere zur Zeit erh�ltliche, kostenlose Probeversion bietet Ihnen die M�glichkeit, bis 
zu 3 CBT-Programme selbst zu testen und aufzunehmen. Falls Sie danach Interesse 
haben dieses Instrument  weiter einzusetzen, k�nnen Sie Ihren Kriterienkatalog f�r 
eine Geb�hr von DM 98,00 "freischalten" lassen. Ihre Fragen und W�nsche richten 
Sie bitte an die:


VW Coaching Gesellschaft mbH
Selbstlernzentrum
Brieffach 0616
38436 Wolfsburg
Tel.: 05361-9-22380
Fax.: 05361-9-26989
e-mail: heike.woelke@volkswagen.de

Ihre Tips, Hinweise und Anregungen nehmen wir gerne unter der o.g. Adresse ent-
gegen. Bitte helfen auch Sie mit, dieses Instrument weiter zu verbessern.
Wir w�nschen Ihnen viel Erfolg bei Ihren CBT-Beurteilungen.


Ihr AKAB-Selbstlernen Team

Noch drei kleine Tips:
- Lesen Sie sich bitte nach dem Start des Programms die Hilfe zum AKAB CBT-
Kriterienkatalog durch.
- Sie k�nnen den AKAB CBT-Kriterienkatalog unter Windows 3.x und Windows 95 
installieren, leider z.Zt. noch nicht unter Windows NT.
- K�ufer unseres Kriterienkataloges erhalten zus�tzlich noch eine "Papierversion" 
des AKAB CBT-Krieterienkatalogs.


